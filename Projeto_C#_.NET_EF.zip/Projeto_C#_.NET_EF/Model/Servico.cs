﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Servico
{
    public int CodServico { get; set; }

    public string? Descricao { get; set; }

    public decimal? Preco { get; set; }

    public virtual ICollection<ServicosReserva> ServicosReservas { get; set; } = new List<ServicosReserva>();
}
