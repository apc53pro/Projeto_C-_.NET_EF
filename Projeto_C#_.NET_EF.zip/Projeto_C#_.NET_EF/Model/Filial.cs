﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Filial
{
    public int CodFilial { get; set; }

    public string? NomeFilial { get; set; }

    public string? EnderecoFilial { get; set; }

    public int? EstrelasFilial { get; set; }

    public int? QuantidadeQuartosFilialSolteiro { get; set; }

    public int? QuantidadeQuartosFilialCasal { get; set; }

    public int? QuantidadeQuartosFilialPresidencial { get; set; }

    public int? QuantidadeQuartosFilialFamilia { get; set; }

    public virtual ICollection<Quarto> Quartos { get; set; } = new List<Quarto>();
}
