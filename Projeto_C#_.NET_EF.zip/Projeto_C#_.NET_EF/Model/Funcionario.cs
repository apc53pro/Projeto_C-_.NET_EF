﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Funcionario
{
    public int CodFuncionario { get; set; }

    public string? Nome { get; set; }

    public string? Funcao { get; set; }

    public int? CodCargo { get; set; }

    public virtual Cargo? CodCargoNavigation { get; set; }

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
}
