﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Quarto
{
    public string Numero { get; set; } = null!;

    public string? Tipo { get; set; }

    public string? Status { get; set; }

    public int? Capacidade { get; set; }

    public byte? CapacidadeOp { get; set; }

    public int? CodFilial { get; set; }

    public virtual Filial? CodFilialNavigation { get; set; }

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
}
