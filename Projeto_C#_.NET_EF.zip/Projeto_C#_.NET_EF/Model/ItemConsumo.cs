﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class ItemConsumo
{
    public int CodConsumo { get; set; }

    public string? Descricao { get; set; }

    public decimal? Preco { get; set; }

    public bool? EntregueQuarto { get; set; }

    public virtual ICollection<ConsumoReserva> ConsumoReservas { get; set; } = new List<ConsumoReserva>();
}
