﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Reserva
{
    public int CodReserva { get; set; }

    public DateOnly? DataIn { get; set; }

    public DateOnly? DataOut { get; set; }

    public string? Numero { get; set; }

    public int? CodFuncionario { get; set; }

    public int? CodCliente { get; set; }

    public virtual Cliente? CodClienteNavigation { get; set; }

    public virtual Funcionario? CodFuncionarioNavigation { get; set; }

    public virtual ICollection<ConsumoReserva> ConsumoReservas { get; set; } = new List<ConsumoReserva>();

    public virtual ICollection<Estadium> Estadia { get; set; } = new List<Estadium>();

    public virtual Quarto? NumeroNavigation { get; set; }

    public virtual ICollection<ServicosReserva> ServicosReservas { get; set; } = new List<ServicosReserva>();
}
