﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Projeto_C__.NET_EF.Model;

public partial class HotelEdisContext : DbContext
{
    public HotelEdisContext()
    {
    }

    public HotelEdisContext(DbContextOptions<HotelEdisContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Cargo> Cargos { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<ConsumoReserva> ConsumoReservas { get; set; }

    public virtual DbSet<Estadium> Estadia { get; set; }

    public virtual DbSet<Filial> Filials { get; set; }

    public virtual DbSet<Funcionario> Funcionarios { get; set; }

    public virtual DbSet<ItemConsumo> ItemConsumos { get; set; }

    public virtual DbSet<Quarto> Quartos { get; set; }

    public virtual DbSet<Reserva> Reservas { get; set; }

    public virtual DbSet<Servico> Servicos { get; set; }

    public virtual DbSet<ServicosReserva> ServicosReservas { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP-ENECNAN\\SQLEXPRESS;Database=Hotel_Edis;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cargo>(entity =>
        {
            entity.HasKey(e => e.CodCargo).HasName("PK__Cargos__362A2F93BCA883AD");

            entity.Property(e => e.CodCargo)
                .ValueGeneratedNever()
                .HasColumnName("codCargo");
            entity.Property(e => e.Descricao)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("descricao");
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.CodCliente).HasName("PK__Cliente__DF8324D7AE4C7897");

            entity.ToTable("Cliente");

            entity.Property(e => e.EMail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("E_mail");
            entity.Property(e => e.Endereco)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Nacionalidade)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Telefone)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ConsumoReserva>(entity =>
        {
            entity.HasKey(e => new { e.CodConsumo, e.CodReserva }).HasName("pk_codConsumoReserva");

            entity.Property(e => e.CodConsumo).HasColumnName("codConsumo");
            entity.Property(e => e.CodReserva).HasColumnName("codReserva");
            entity.Property(e => e.Quantidade).HasColumnName("quantidade");

            entity.HasOne(d => d.CodConsumoNavigation).WithMany(p => p.ConsumoReservas)
                .HasForeignKey(d => d.CodConsumo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ConsumoRe__codCo__05D8E0BE");

            entity.HasOne(d => d.CodReservaNavigation).WithMany(p => p.ConsumoReservas)
                .HasForeignKey(d => d.CodReserva)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ConsumoRe__codRe__06CD04F7");
        });

        modelBuilder.Entity<Estadium>(entity =>
        {
            entity.HasKey(e => e.CodEstadia).HasName("PK__Estadia__A423EC7F2FEB2963");

            entity.Property(e => e.FormaPagamento)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Forma_Pagamento");

            entity.HasOne(d => d.CodReservaNavigation).WithMany(p => p.Estadia)
                .HasForeignKey(d => d.CodReserva)
                .HasConstraintName("fk_CodReserva");
        });

        modelBuilder.Entity<Filial>(entity =>
        {
            entity.HasKey(e => e.CodFilial).HasName("PK__Filial__97E309FA467EBD4D");

            entity.ToTable("Filial");

            entity.Property(e => e.CodFilial)
                .ValueGeneratedNever()
                .HasColumnName("codFilial");
            entity.Property(e => e.EnderecoFilial)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("enderecoFilial");
            entity.Property(e => e.EstrelasFilial).HasColumnName("estrelasFilial");
            entity.Property(e => e.NomeFilial)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nomeFilial");
            entity.Property(e => e.QuantidadeQuartosFilialCasal).HasColumnName("quantidadeQuartosFilialCasal");
            entity.Property(e => e.QuantidadeQuartosFilialFamilia).HasColumnName("quantidadeQuartosFilialFamilia");
            entity.Property(e => e.QuantidadeQuartosFilialPresidencial).HasColumnName("quantidadeQuartosFilialPresidencial");
            entity.Property(e => e.QuantidadeQuartosFilialSolteiro).HasColumnName("quantidadeQuartosFilialSolteiro");
        });

        modelBuilder.Entity<Funcionario>(entity =>
        {
            entity.HasKey(e => e.CodFuncionario).HasName("PK__Funciona__E470B745C154412B");

            entity.ToTable("Funcionario");

            entity.Property(e => e.CodCargo).HasColumnName("codCargo");
            entity.Property(e => e.Funcao)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.CodCargoNavigation).WithMany(p => p.Funcionarios)
                .HasForeignKey(d => d.CodCargo)
                .HasConstraintName("fk_codCargo");
        });

        modelBuilder.Entity<ItemConsumo>(entity =>
        {
            entity.HasKey(e => e.CodConsumo).HasName("PK__ItemCons__223167821C01E8A4");

            entity.Property(e => e.CodConsumo)
                .ValueGeneratedNever()
                .HasColumnName("codConsumo");
            entity.Property(e => e.Descricao)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("descricao");
            entity.Property(e => e.EntregueQuarto).HasColumnName("entregueQuarto");
            entity.Property(e => e.Preco)
                .HasColumnType("decimal(7, 2)")
                .HasColumnName("preco");
        });

        modelBuilder.Entity<Quarto>(entity =>
        {
            entity.HasKey(e => e.Numero).HasName("PK__Quarto__7E532BC7D404628D");

            entity.ToTable("Quarto");

            entity.Property(e => e.Numero)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CapacidadeOp).HasColumnName("Capacidade_Op");
            entity.Property(e => e.CodFilial).HasColumnName("codFilial");
            entity.Property(e => e.Status)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Tipo)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.CodFilialNavigation).WithMany(p => p.Quartos)
                .HasForeignKey(d => d.CodFilial)
                .HasConstraintName("fk_codFilial");
        });

        modelBuilder.Entity<Reserva>(entity =>
        {
            entity.HasKey(e => e.CodReserva).HasName("PK__Reserva__A7508B91DDD4F730");

            entity.ToTable("Reserva");

            entity.Property(e => e.DataIn).HasColumnName("Data_In");
            entity.Property(e => e.DataOut).HasColumnName("Data_Out");
            entity.Property(e => e.Numero)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.CodClienteNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.CodCliente)
                .HasConstraintName("fk_Cliente_CodCliente");

            entity.HasOne(d => d.CodFuncionarioNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.CodFuncionario)
                .HasConstraintName("fk_Funcionario_CodFuncionario");

            entity.HasOne(d => d.NumeroNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.Numero)
                .HasConstraintName("fk_Quarto_Numero");
        });

        modelBuilder.Entity<Servico>(entity =>
        {
            entity.HasKey(e => e.CodServico).HasName("PK__Servicos__5AD7160026A834EB");

            entity.Property(e => e.CodServico)
                .ValueGeneratedNever()
                .HasColumnName("codServico");
            entity.Property(e => e.Descricao)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("descricao");
            entity.Property(e => e.Preco)
                .HasColumnType("decimal(7, 2)")
                .HasColumnName("preco");
        });

        modelBuilder.Entity<ServicosReserva>(entity =>
        {
            entity.HasKey(e => new { e.CodServico, e.CodReserva }).HasName("pk_codServicoReserva");

            entity.Property(e => e.CodServico).HasColumnName("codServico");
            entity.Property(e => e.CodReserva).HasColumnName("codReserva");
            entity.Property(e => e.Quantidade).HasColumnName("quantidade");

            entity.HasOne(d => d.CodReservaNavigation).WithMany(p => p.ServicosReservas)
                .HasForeignKey(d => d.CodReserva)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ServicosR__codRe__00200768");

            entity.HasOne(d => d.CodServicoNavigation).WithMany(p => p.ServicosReservas)
                .HasForeignKey(d => d.CodServico)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ServicosR__codSe__7F2BE32F");
        });

        OnModelCreatingPartial(modelBuilder);
    }
    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
