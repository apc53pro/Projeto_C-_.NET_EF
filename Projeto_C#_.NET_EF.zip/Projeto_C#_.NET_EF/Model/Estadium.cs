﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Estadium
{
    public int CodEstadia { get; set; }

    public double? Valor { get; set; }

    public string? FormaPagamento { get; set; }

    public int? CodReserva { get; set; }

    public virtual Reserva? CodReservaNavigation { get; set; }
}
