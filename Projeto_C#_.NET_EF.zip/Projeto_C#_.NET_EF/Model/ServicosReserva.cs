﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class ServicosReserva
{
    public int CodServico { get; set; }

    public int CodReserva { get; set; }

    public int? Quantidade { get; set; }

    public virtual Reserva CodReservaNavigation { get; set; } = null!;

    public virtual Servico CodServicoNavigation { get; set; } = null!;
}
