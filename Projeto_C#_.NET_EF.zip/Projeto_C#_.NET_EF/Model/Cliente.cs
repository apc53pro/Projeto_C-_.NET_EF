﻿using System;
using System.Collections.Generic;

namespace Projeto_C__.NET_EF.Model;

public partial class Cliente
{
    public int CodCliente { get; set; }

    public string? Nome { get; set; }

    public string? Nacionalidade { get; set; }

    public string? Endereco { get; set; }

    public string? EMail { get; set; }

    public string? Telefone { get; set; }

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
}
