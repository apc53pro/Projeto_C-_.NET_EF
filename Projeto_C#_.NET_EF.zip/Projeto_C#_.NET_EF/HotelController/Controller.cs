using Microsoft.AspNetCore.Mvc;

namespace Projeto_C__.NET_EF.Model
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelController : Controller
    {
        [HttpGet("GetBySheet/{sheet}")]
        public IActionResult Get(string sheet)
        {
            using (var _context = new HotelEdisContext())
            {               
                if(sheet == "Cargos" || sheet == "cargos")
                {   
                    List<Cargo> lista_cargos = new (_context.Cargos.ToList());
                    return Ok(lista_cargos);
                }

                if(sheet == "Clientes" || sheet == "clientes")
                {
                    List<Cliente> lista_clientes = new (_context.Clientes.ToList());
                    return Ok(lista_clientes);
                }

                if(sheet == "ConsumoReserva" || sheet == "consumoreserva" || sheet == "Consumoreserva" || sheet == "consumoReserva")
                {
                    List<ConsumoReserva> lista_ConReserva = new (_context.ConsumoReservas.ToList());
                    return Ok(lista_ConReserva);
                }

                if(sheet == "Estadia" || sheet == "estadia")
                {
                    List<Estadium> lista_estadia = new (_context.Estadia.ToList());
                    return Ok(lista_estadia);
                }

                if(sheet == "Filiais" || sheet == "filiais")
                {
                    List<Filial> lista_filials = new (_context.Filials.ToList());
                    return Ok(lista_filials);
                }

                if(sheet == "Funcionarios" || sheet == "funcionarios")
                {
                    List<Funcionario> lista_funcionario = new (_context.Funcionarios.ToList());
                    return Ok(lista_funcionario);
                }

                if(sheet == "ItensConsumo" || sheet == "itensconsumo" || sheet == "itensConsumo" || sheet == "Itensconsumo")
                {
                    List<ItemConsumo> lista_itemConsumo = new (_context.ItemConsumos.ToList());
                    return Ok(lista_itemConsumo);
                }

                if(sheet == "Quartos" || sheet == "quartos")
                {
                    List<Quarto> lista_quartos = new (_context.Quartos.ToList());
                    return Ok(lista_quartos);
                }

                if(sheet == "Reservas" || sheet == "reservas")
                {
                    List<Reserva> lista_Reservas = new (_context.Reservas.ToList());
                    return Ok(lista_Reservas);
                }

                if(sheet == "Serviços" || sheet == "serviços")
                {
                    List<Servico> lista_servicos = new (_context.Servicos.ToList());
                    return Ok(lista_servicos);
                }

                if(sheet == "ServiçosReserva" || sheet == "serviçosreserva" || sheet == "Serviçosreserva" || sheet == "serviçosReserva")
                {
                    List<ServicosReserva> lista_servicosReservas = new (_context.ServicosReservas.ToList());
                    return Ok(lista_servicosReservas);
                }
                return NotFound("Tabela nao encontrada.");
            }
        }

        [HttpPost("PostCargo")]
        public IActionResult PostCargo(int cargoid, string descricao)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Cargo novo_cargo = new();
                    novo_cargo.CodCargo = cargoid;
                    novo_cargo.Descricao = descricao;
                    foreach(Cargo c in _context.Cargos)
                    {
                        if(c.CodCargo == novo_cargo.CodCargo)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um CARGO com esse codigo");
                        }
                    }
                    _context.Cargos.Add(novo_cargo);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostCliente")]
        public IActionResult PostClient(int codCliente, string nome, string Nacionalidade, string Endereco, string EMail, string Telefone )
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Cliente novo_cliente = new();
                    novo_cliente.CodCliente = codCliente;
                    novo_cliente.Nome = nome;
                    novo_cliente.Nacionalidade = Nacionalidade;
                    novo_cliente.Endereco = Endereco;
                    novo_cliente.EMail = EMail;
                    novo_cliente.Telefone = Telefone;
                    
                    foreach(Cliente c in _context.Clientes)
                    {
                        if(c.CodCliente == novo_cliente.CodCliente)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um CLIENTE com esse codigo");
                        }
                    }
                    _context.Clientes.Add(novo_cliente);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostConsumoReserva")]
        public IActionResult PostConsumoReserva(int codConsumo, int codReserva, int quantidade)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    ConsumoReserva novo_ConsumoReserva = new();
                    novo_ConsumoReserva.CodConsumo = codConsumo;
                    novo_ConsumoReserva.CodReserva = codReserva;
                    novo_ConsumoReserva.Quantidade = quantidade;
                    
                    foreach(ConsumoReserva c in _context.ConsumoReservas)
                    {
                        if(c.CodConsumo == novo_ConsumoReserva.CodConsumo)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um item CONSUMO com esse codigo");
                        }
                    }
                    _context.ConsumoReservas.Add(novo_ConsumoReserva);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostEstadia")]
        public IActionResult PostEstadia(int codEstadia, double valor, string formaPagamento, int codReserva)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Estadium novo_Estadia = new();
                    novo_Estadia.CodEstadia = codEstadia;
                    novo_Estadia.Valor = valor;
                    novo_Estadia.FormaPagamento = formaPagamento;
                    novo_Estadia.CodReserva = codReserva;
                    
                    foreach(Estadium c in _context.Estadia)
                    {
                        if(c.CodEstadia == novo_Estadia.CodReserva)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um item ESTADIA com esse codigo");
                        }
                    }
                    _context.Estadia.Add(novo_Estadia);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostFilial")]
        public IActionResult PostFilial(int codFilial, string nomeFilial, string enderecoFilial, int estrelasFilial, int quantidadeQuartosFilialSolteiro, int quantidadeQuartosFilialCasal, int quantidadeQuartosFilialPresidencial, int quantidadeQuartosFilialFamilia)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Filial novo_Filial = new();
                    novo_Filial.CodFilial = codFilial;
                    novo_Filial.NomeFilial = nomeFilial;
                    novo_Filial.EnderecoFilial = enderecoFilial;
                    novo_Filial.EstrelasFilial = estrelasFilial;
                    novo_Filial.QuantidadeQuartosFilialSolteiro = quantidadeQuartosFilialSolteiro;
                    novo_Filial.QuantidadeQuartosFilialCasal = quantidadeQuartosFilialCasal;
                    novo_Filial.QuantidadeQuartosFilialPresidencial = quantidadeQuartosFilialPresidencial;
                    novo_Filial.QuantidadeQuartosFilialFamilia = quantidadeQuartosFilialFamilia;
                    
                    foreach(Filial c in _context.Filials)
                    {
                        if(c.CodFilial == novo_Filial.CodFilial)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um item ESTADIA com esse codigo");
                        }
                    }
                    _context.Filials.Add(novo_Filial);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostFuncionario")]
        public IActionResult PostFuncionario(int codFuncionario, string nome, string funcao, int codCargo)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Funcionario novo_Funcionario = new();
                    novo_Funcionario.CodFuncionario = codFuncionario;
                    novo_Funcionario.Nome = nome;
                    novo_Funcionario.Funcao = funcao;
                    novo_Funcionario.CodCargo = codCargo;
                    
                    foreach(Funcionario c in _context.Funcionarios)
                    {
                        if(c.CodFuncionario == novo_Funcionario.CodFuncionario)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um item FUNCIONARIO com esse codigo");
                        }
                    }
                    _context.Funcionarios.Add(novo_Funcionario);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPost("PostItemConsumo")]
        public IActionResult PostItemConsumo(int codConsumo, string descricao, decimal preco, bool entregueQuarto)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    ItemConsumo novo_ItemConsumo = new();
                    novo_ItemConsumo.CodConsumo = codConsumo;
                    novo_ItemConsumo.Descricao = descricao;
                    novo_ItemConsumo.Preco = preco;
                    novo_ItemConsumo.EntregueQuarto = entregueQuarto;
                    
                    foreach(ItemConsumo c in _context.ItemConsumos)
                    {
                        if(c.CodConsumo == novo_ItemConsumo.CodConsumo)
                        {
                            return BadRequest("ERRO DE CADASTRO: Já existe um item ITEM_CONSUMO com esse codigo");
                        }
                    }
                    _context.ItemConsumos.Add(novo_ItemConsumo);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }
        
        [HttpPost("PostQuarto")]
        public IActionResult PostQuarto( string Numero, string Tipo, string Status, int Capacidade, byte CapacidadeOp,int CodFilial)
        {   
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Quarto novo_quarto= new();
                    novo_quarto.Numero = Numero;
                    novo_quarto.Tipo = Tipo;
                    novo_quarto.Status = Status;
                    novo_quarto.Capacidade = Capacidade;
                    novo_quarto.CapacidadeOp = CapacidadeOp;
                    novo_quarto.CodFilial = CodFilial;
                    
                    foreach(Quarto c in _context.Quartos)
                    {
                        if(c.Numero == novo_quarto.Numero)
                        {
                            return BadRequest("ERRO: Já existe um item QUARTO com esse NUMERO");
                        }
                    }
                    _context.Quartos.Add(novo_quarto);
                    _context.SaveChanges();

                    return Ok("RESERVA FEITA, LEMBRE-SE DE VALIDAR ANTES DAS 24H DO HORARIO DE CHECK-IN!!");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }

        [HttpPost("PostReserva")]
        public IActionResult PostReserva( int CodReserva, DateOnly DataIn, DateOnly DataOut, string Numero, int CodFuncionario, int CodCliente)
        {   
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Reserva nova_reserva = new();
                    nova_reserva.CodReserva = CodReserva;
                    nova_reserva.DataIn = DataIn;
                    nova_reserva.DataOut = DataOut;
                    nova_reserva.Numero = Numero;
                    nova_reserva.CodFuncionario = CodFuncionario;
                    nova_reserva.CodCliente = CodCliente;
                    
                    foreach(Reserva c in _context.Reservas)
                    {
                        if(c.CodReserva == nova_reserva.CodReserva)
                        {
                            return BadRequest("ERRO: Já existe um RESERVA com esse codigo");
                        }
                    }
                    _context.Reservas.Add(nova_reserva);
                    _context.SaveChanges();

                    return Ok("RESERVA FEITA, LEMBRE-SE DE VALIDAR ANTES DAS 24H DO HORARIO DE CHECK-IN!!");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }


        [HttpPost("PostServico")]
        public IActionResult PostServico(int codServico, string descricao, decimal preco)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    Servico novo_Servico = new();
                    novo_Servico.CodServico = codServico;
                    novo_Servico.Descricao = descricao;
                    novo_Servico.Preco = preco;
                    
                    foreach(Servico c in _context.Servicos)
                    {
                        if(c.CodServico == novo_Servico.CodServico)
                        {
                            return BadRequest("ERRO: Já existe um serviço com esse codigo");
                        }
                    }
                    _context.Servicos.Add(novo_Servico);
                    _context.SaveChanges();

                    return Ok("SUCESSO NA OPERAÇÃO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }

        [HttpPost("PostServicosReserva")]
        public IActionResult PostServReserva(int codServico, int CodReserva, int Quantidade)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    ServicosReserva novo_SerReserva = new();
                    novo_SerReserva.CodServico = codServico;
                    novo_SerReserva.CodServico = CodReserva;
                    novo_SerReserva.Quantidade = Quantidade;
                    
                    foreach(ServicosReserva c in _context.ServicosReservas)
                    {
                        if(c.CodServico == novo_SerReserva.CodServico)
                        {
                            return BadRequest("ERRO: Já existe um serviço com esse codigo");
                        }
                    }
                    _context.ServicosReservas.Add(novo_SerReserva);
                    _context.SaveChanges();

                    return Ok("SUCESSO NA OPERAÇÃO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPut("PutCargo")]
        public IActionResult UpdateCargos(int cargoid, string descricao)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    var item = _context.Cargos.FirstOrDefault(t => t.CodCargo == cargoid);

                    item.Descricao = descricao;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + cargoid + " da lista CARGO foi atualizado com sucesso.");
                }
                catch
                {
                    return BadRequest("Operação nao concluida.");
                }
            }
        }

        [HttpPut("PutCliente")]
        public IActionResult PutClient(int codCliente, string nome, string Nacionalidade, string Endereco, string EMail, string Telefone )
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Clientes.FirstOrDefault(t => t.CodCliente == codCliente);

                    item.Nome = nome;
                    item.Nacionalidade = Nacionalidade;
                    item.Endereco = Endereco;
                    item.EMail = EMail;
                    item.Telefone = Telefone;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codCliente + " da lista CLIENTE foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }
        
        [HttpPut("PutConsumoReserva")]
        public IActionResult PutConsumoReserva(int codConsumo, int codReserva, int quantidade)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.ConsumoReservas.FirstOrDefault(t => t.CodConsumo == codConsumo);
                    
                    item.Quantidade = quantidade;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codConsumo + " da lista CONSUMORESERVA foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPut("PutEstadia")]
        public IActionResult PutEstadia(int codEstadia, double valor, string formaPagamento, int codReserva)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Estadia.FirstOrDefault(t => t.CodEstadia == codEstadia);

                    item.Valor = valor;
                    item.FormaPagamento = formaPagamento;
                    item.CodReserva = codReserva;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codEstadia + " da lista ESTADIA foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPut("PutFilial")]
        public IActionResult PutFilial(int codFilial, string nomeFilial, string enderecoFilial, int estrelasFilial, int quantidadeQuartosFilialSolteiro, int quantidadeQuartosFilialCasal, int quantidadeQuartosFilialPresidencial, int quantidadeQuartosFilialFamilia)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Filials.FirstOrDefault(t => t.CodFilial == codFilial);

                    item.NomeFilial = nomeFilial;
                    item.EnderecoFilial = enderecoFilial;
                    item.EstrelasFilial = estrelasFilial;
                    item.QuantidadeQuartosFilialSolteiro = quantidadeQuartosFilialSolteiro;
                    item.QuantidadeQuartosFilialCasal = quantidadeQuartosFilialCasal;
                    item.QuantidadeQuartosFilialPresidencial = quantidadeQuartosFilialPresidencial;
                    item.QuantidadeQuartosFilialFamilia = quantidadeQuartosFilialFamilia;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codFilial + " da lista FILIAIS foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPut("PutFuncionario")]
        public IActionResult PutFuncionario(int codFuncionario, string nome, string funcao, int codCargo)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Funcionarios.FirstOrDefault(t => t.CodFuncionario == codFuncionario);

                    item.Nome = nome;
                    item.Funcao = funcao;
                    item.CodCargo = codCargo;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codFuncionario + " da lista FUNCIONARIOS foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPut("PutItemConsumo")]
        public IActionResult PutItemConsumo(int codConsumo, string descricao, decimal preco, bool entregueQuarto)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.ItemConsumos.FirstOrDefault(t => t.CodConsumo == codConsumo);

                    item.Descricao = descricao;
                    item.Preco = preco;
                    item.EntregueQuarto = entregueQuarto;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codConsumo + " da lista FUNCIONARIOS foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
                
            }
        }

        [HttpPut("PutQuarto")]
        public IActionResult UpdateQuarto(string numero, string tipo, string status, int capacidade, byte capacidadeOp,int codFilial)
        {   
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Quartos.FirstOrDefault(R => R.Numero == numero);
                    
                    item.Tipo = tipo;
                    item.Status = status;
                    item.Capacidade = capacidade;
                    item.CapacidadeOp = capacidadeOp;
                    item.CodFilial = codFilial;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Quarto atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }

        [HttpPut("PutReserva")]
        public IActionResult UpdateReserva( int CodReserva, DateOnly DataIn, DateOnly DataOut, string Numero, int CodFuncionario, int CodCliente)
        {   
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Reservas.FirstOrDefault(R => R.CodReserva == CodReserva);
                    
                    item.DataIn = DataIn;
                    item.DataOut = DataOut;
                    item.Numero = Numero;
                    
                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Reserva atualizada com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }
        

        [HttpPut("PutServico")]
        public IActionResult UpdateServico(int CodServico, string descricao, decimal preco)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.Servicos.FirstOrDefault(S => S.CodServico == CodServico);

                    item.Descricao = descricao;
                    item.Preco = preco;
                    
                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + CodServico + " da lista Serviços foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
            
        }


        [HttpPut("PutServicosReserva")]
        public IActionResult UpdateServReserva(int codServico, int codReserva, int Quantidade)
        { 
            using (var _context = new HotelEdisContext())
            {                      
                try
                {   
                    var item = _context.ServicosReservas.FirstOrDefault(S => S.CodServico == codServico);

                    item.Quantidade = Quantidade;

                    _context.Entry(item).CurrentValues.SetValues(item);
                    _context.SaveChanges();

                    return Ok("Item " + codServico + " da lista Serviços Reserva foi atualizado com sucesso.");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }
        
        [HttpDelete("DeleteBySheet/{sheet}/{sheetItem}")]
        public IActionResult Delete(string sheet, int sheetItem, string NumQuarto)
        {
            using (var _context = new HotelEdisContext())
            {               
                
                if(sheet == "Cargos" || sheet == "cargos")
                {   
                    try
                    {
                        var item = _context.Cargos.FirstOrDefault(t => t.CodCargo == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Cargos.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Clientes" || sheet == "clientes")
                {   
                    try
                    {
                        var item = _context.Clientes.FirstOrDefault(t => t.CodCliente == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }
                        
                        _context.Clientes.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "ConsumoReserva" || sheet == "Consumoreserva" || sheet == "consumoreserva" || sheet == "consumoReseva")
                {   
                    try
                    {
                        var item = _context.ConsumoReservas.FirstOrDefault(t => t.CodConsumo == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.ConsumoReservas.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Estadia" || sheet == "estadia")
                {   
                    try
                    {
                        var item = _context.Estadia.FirstOrDefault(t => t.CodEstadia == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Estadia.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Filiais" || sheet == "filiais")
                {   
                    try
                    {
                        var item = _context.Filials.FirstOrDefault(t => t.CodFilial == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Filials.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Funcionarios" || sheet == "funcionarios")
                {   
                    try
                    {
                        var item = _context.Funcionarios.FirstOrDefault(t => t.CodFuncionario == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Funcionarios.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "ItensConsumo" || sheet == "itensconsumo" || sheet == "Itensconsumo" || sheet == "itensConsumo")
                {   
                    try
                    {
                        var item = _context.ItemConsumos.FirstOrDefault(t => t.CodConsumo == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.ItemConsumos.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }
     
                if(sheet == "Quartos" || sheet == "quartos")
                {   
                    try
                    {
                        var item = _context.Quartos.FirstOrDefault(t => t.Numero == NumQuarto);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        List<Reserva> lista_reservas = _context.Reservas.ToList();

                        foreach(Reserva reserva in lista_reservas)
                        {
                            if(reserva.Numero == NumQuarto){
                                return BadRequest("QUARTO NÃO PODE SER DELETADO PORQUE EXISTE UMA RESERVA");
                            }
                        }

                        _context.Quartos.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + NumQuarto + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Reservas" || sheet == "reservas")
                {   
                    try
                    {
                        var item = _context.Reservas.FirstOrDefault(t => t.CodReserva == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Reservas.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "Servicos" || sheet == "servico")
                {   
                    try
                    {
                        var item = _context.Servicos.FirstOrDefault(t => t.CodServico == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.Servicos.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                if(sheet == "ServiçosReserva" || sheet == "serviçosreserva" || sheet == "Serviçosreserva" || sheet == "serviçosReserva")
                {   
                    try
                    {
                        var item = _context.ServicosReservas.FirstOrDefault(t => t.CodServico == sheetItem);

                        if(item == null)
                        {
                            return NotFound(sheet.ToUpper() + " NÃO ENCONTRADO.");
                        }

                        _context.ServicosReservas.Remove(item);
                        _context.SaveChanges();

                        return Ok("Item " + sheetItem + " da lista " + sheet.ToUpper() + " foi deletado com sucesso.");
                    }
                    catch
                    {
                        return BadRequest("Operacao nao concluida.");
                    }
                }

                return BadRequest();
            }
        }
    }   
}